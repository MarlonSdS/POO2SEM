
package main;

import objetos.Onibus;
import objetos.Pessoa;

/**
 *
 * @author Marlon Santana dos S
 */
public class Principal {
    
    public static void main(String[] args) {
    Pessoa P1 = new Pessoa();
    Pessoa P2 = new Pessoa();
    
    P1.nome = "João";
    P2.nome = "Maria";
    
    P1.cpf = "1212121212";
    P2.cpf = "2323232323";
    
    P1.idade = 18;
    P2.idade = 19;
    
    P1.nacionalidade = "BR";
    P2.nacionalidade = "BR";
    
    P1.telefone = "8888888888";
    P2.telefone = "9999999999";
    
        System.out.println(P1.nome);
        System.out.println(P2.nome);
        System.out.println(P1.cpf);
        System.out.println(P2.cpf);
        System.out.println(P1.idade);
        System.out.println(P2.idade);
        System.out.println(P1.nacionalidade);
        System.out.println(P2.nacionalidade);
        System.out.println(P1.telefone);
        System.out.println(P2.telefone);
        
    }
}
