
package objetos;

/**
 *
 * @author Marlon Santana dos S
 */
public class Pessoa {
    public String nome;
    public String cpf;
    public String telefone;
    public int idade;
    public String nacionalidade;
    
    public static void informarPessoa(){
        
    }
}
