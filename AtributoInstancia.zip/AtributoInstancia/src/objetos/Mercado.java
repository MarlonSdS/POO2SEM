
package objetos;

/**
 *
 * @author Marlon Santana dos S
 */
public class Mercado {
    public String endereco;
    public String cnpj;
    public String nome;
    public int numFuncionarios;
    public int horaAbertura;
    
}
