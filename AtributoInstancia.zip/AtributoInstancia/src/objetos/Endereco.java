
package objetos;

/**
 *
 * @author Marlon Santana dos S
 */
public class Endereco {
    public int numero;
    public String rua;
    public String bairro;
    public String cidade;
    public String estado;
    
}
