
package objetos;

/**
 *
 * @author Marlon Santana dos S
 */
public class Onibus {
    public int numPassageiros;
    public String saida;
    public String destino;
    public int horaSaida;
    public int horaChegada;
    
}
