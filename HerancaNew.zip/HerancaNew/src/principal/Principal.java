
package principal;

import animal.Cachorro;
import animal.Gato;

/**
 *
 * @author Marlon Santana dos Santos
 */
public class Principal {
    public static void main(String[] args){
        Cachorro c1 = new Cachorro("Branco", 20.5, true);
        Gato g1 = new Gato("Amarelo", 5.0);
        
        
    }
}
