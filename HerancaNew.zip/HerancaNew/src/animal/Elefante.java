
package animal;

/**
 *
 * @author Marlon Santana dos Santos
 */
public class Elefante extends Animal{
    private boolean possuiMarfim;
    
    public Elefante (String cor, double peso, boolean possuiMarfim){
        super(cor, peso);
        this.possuiMarfim = possuiMarfim;
        
    }

    public boolean isPossuiMarfim() {
        return possuiMarfim;
    }

    public void setPossuiMarfim(boolean possuiMarfim) {
        this.possuiMarfim = possuiMarfim;
    }
}
