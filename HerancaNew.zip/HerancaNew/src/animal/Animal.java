
package animal;

/**
 *
 * @author Marlon Santana dos Santos
 */
public class Animal {
    private String cor;
    private double peso;
    private double altura;
    
    public Animal(String cor, double peso){
        this.cor = cor;
        this.peso = peso;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }
    
}
