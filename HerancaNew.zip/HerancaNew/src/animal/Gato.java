
package animal;

/**
 *
 * @author Marlon Santana dos Santos
 */
public class Gato extends Animal{
    
    public Gato(String cor, double peso){
        super(cor, peso);
    }
}
