
package animal;

/**
 *
 * @author Marlon Santana dos Santos
 */
public class Cachorro extends Animal{
    
    private boolean raboCachorro;
    
    public Cachorro(String cor, double peso, boolean raboCachorro){
        super(cor, peso);
        this.raboCachorro = raboCachorro;
    }

    public boolean isRaboCachorro() {
        return raboCachorro;
    }

    public void setRaboCachorro(boolean raboCachorro) {
        this.raboCachorro = raboCachorro;
    }
}
