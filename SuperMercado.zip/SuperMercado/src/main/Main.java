
package main;

import produto.Chocolate;
import produto.Miojo;
import produto.SucoDeLaranja;

/**
 *
 * @author Marlon Santana dos Santos
 */
public class Main {
    public static void main(String[] args) {
        Chocolate nestle = new Chocolate();
        Miojo nissin = new Miojo();
        SucoDeLaranja fanta = new SucoDeLaranja();
        
        nestle.setNomeProduto("Chocolate em barra");
        nissin.setNomeProduto("Miojo de galinha");
        fanta.setNomeProduto("Fanta Laranja");
        
        System.out.println(nestle.getNomeProduto());
        System.out.println(nissin.getNomeProduto());
        System.out.println(fanta.getNomeProduto());
        
    }
}
