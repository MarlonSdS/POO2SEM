
package produto;

/**
 *
 * @author LABORATORIO 01
 */
public class SucoDeLaranja extends Produto {
    
}
