
package produto;

/**
 *
 * @author LABORATORIO 01
 */
public class Chocolate extends Produto{
    
}
