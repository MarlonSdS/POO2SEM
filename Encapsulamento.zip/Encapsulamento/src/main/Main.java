package main;

import pacote.AlunoPacote;
import privado.AlunoPrivado;
import protegido.AlunoProtegido;
import publico.AlunoPublico;

public class Main {
    public static void main(String[] args) {
        AlunoPacote aluno1 = new AlunoPacote(); //pacote e classe
        AlunoPrivado aluno2 = new AlunoPrivado(); //classe
        AlunoProtegido aluno3 = new AlunoProtegido(); //pac, clas, sub
        AlunoPublico aluno4 = new AlunoPublico(); //todos os locais
        
        aluno1.setNome("João");
        aluno2.setNome("João");
        aluno3.setNome("João");
        aluno4.nome = "João";
        
        System.out.println(aluno1.getNome());
        System.out.println(aluno2.getNome());
        System.out.println(aluno3.getNome());
        System.out.println(aluno4.nome);
        
    }
}
