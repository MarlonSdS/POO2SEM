
package faculdade;

/**
 *
 * @author Marlon Santana dos Santos
 */
public class Faxineiro {
    private int cgHrSemanal;
    private int numSalas;
    private String diaFolga;

    public int getCgHrSemanal() {
        return cgHrSemanal;
    }

    public void setCgHrSemanal(int cgHrSemanal) {
        this.cgHrSemanal = cgHrSemanal;
    }

    public int getNumSalas() {
        return numSalas;
    }

    public void setNumSalas(int numSalas) {
        this.numSalas = numSalas;
    }

    public String getDiaFolga() {
        return diaFolga;
    }

    public void setDiaFolga(String diaFolga) {
        this.diaFolga = diaFolga;
    }
}
