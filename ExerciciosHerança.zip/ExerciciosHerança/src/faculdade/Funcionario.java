
package faculdade;

/**
 *
 * @author Marlon Santana dos Santos
 */
public class Funcionario extends Pessoa{
    private double salario;
    private String dtCont;
    private String codId;

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public String getDtCont() {
        return dtCont;
    }

    public void setDtCont(String dtCont) {
        this.dtCont = dtCont;
    }

    public String getCodId() {
        return codId;
    }

    public void setCodId(String codId) {
        this.codId = codId;
    }
}
