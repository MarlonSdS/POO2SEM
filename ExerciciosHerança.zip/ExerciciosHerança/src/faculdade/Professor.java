
package faculdade;

/**
 *
 * @author Marlon Santana dos Santos
 */
public class Professor extends Funcionario{
    private String disciplina;
    private int numTurmas;
    private String formacao;

    public String getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(String disciplina) {
        this.disciplina = disciplina;
    }

    public int getNumTurmas() {
        return numTurmas;
    }

    public void setNumTurmas(int numTurmas) {
        this.numTurmas = numTurmas;
    }

    public String getFormacao() {
        return formacao;
    }

    public void setFormacao(String formacao) {
        this.formacao = formacao;
    }
}
