
package faculdade;

/**
 *
 * @author LABORATORIO 01
 */
public class Monitor extends Alunos{
    private int cgHrSemanal;
    private double remuneracao;
    private String disciplina;

    public int getCgHrSemanal() {
        return cgHrSemanal;
    }

    public void setCgHrSemanal(int cgHrSemanal) {
        this.cgHrSemanal = cgHrSemanal;
    }

    public double getRemuneracao() {
        return remuneracao;
    }

    public void setRemuneracao(double remuneracao) {
        this.remuneracao = remuneracao;
    }

    public String getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(String disciplina) {
        this.disciplina = disciplina;
    }
}
