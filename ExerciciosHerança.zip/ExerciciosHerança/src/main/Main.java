
package main;

import faculdade.Alunos;
import faculdade.Faxineiro;
import faculdade.Monitor;
import faculdade.Professor;

/**
 *
 * @author Marlon Santana dos Santos
 */
public class Main {
    public static void main(String[] args) {
        Alunos al = new Alunos();
        Monitor alM = new Monitor();
        Professor pf = new Professor();
        Faxineiro fx = new Faxineiro();
        
        al.setNome("Marlon");
        al.setCpf("1212121-12");
        al.setTelefone("998370490");
        al.setMatricula("2019121250");
        al.setCurso("ADS");
        al.setSemestre("Segundo");
        
        alM.setNome("Sara");
        alM.setCpf("13131313-13");
        alM.setTelefone("99904660");
        alM.setMatricula("201713450");
        alM.setCurso("ADS");
        alM.setSemestre("Sexto");
        alM.setCgHrSemanal(12);
        alM.setDisciplina("Algoritmos");
        alM.setRemuneracao(200.00);
        
        pf.setNome("Sara Sarasvaty");
        pf.setCpf("4545454554-45");
        pf.setTelefone("1110237980");
        pf.setSalario(2500.00);
        
    }
}
