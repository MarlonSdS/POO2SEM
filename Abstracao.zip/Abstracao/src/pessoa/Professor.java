
package pessoa;

public class Professor extends Pessoa{

    @Override
    public void salvar() {
        System.out.println("Professor cadastrado com sucesso!");
    }
    
}
