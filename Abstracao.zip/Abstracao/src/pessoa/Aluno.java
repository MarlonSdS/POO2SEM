package pessoa;

public class Aluno extends Pessoa{

    @Override
    public void salvar() {
        System.out.println("Aluno Salvo com sucesso!");
    }

    
    
}
