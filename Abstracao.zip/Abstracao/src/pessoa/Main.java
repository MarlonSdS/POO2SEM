
package pessoa;

public class Main {
    
    public static void main(String[] args) {
        Aluno a = new Aluno();
        Professor pf = new Professor();
    }
    
    
}
