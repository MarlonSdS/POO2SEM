package main;

import conta.Conta;

public class Main {
    public static void main(String[] args) {
       Conta c1 = new Conta();
       Conta c2 = new Conta();
       
       Conta.depositar(c1, 500);
       
       c1.realizarSaque(200);
       
       Conta.realizarEmprestimo(5000, 1500, c2);
    }
}
