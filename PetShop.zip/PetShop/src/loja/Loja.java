
package loja;

/**
 *
 * @author Marlon Santana dos Santos
 */
public class Loja {
    public int num;
    public String rua;
    public String bairro;
    
    public Loja(int num, String rua){
        this.num = num;
        this.rua = rua;
    }
}
