
package cliente;

/**
 *
 * @author Marlon Santana dos Santos
 */
public class Cliente {
    public String nome;
    public String cpf;
    public String telefone;
    
    public Cliente(String nome, String cpf){
        this.nome = nome;
        this.cpf = cpf;
    }
}
