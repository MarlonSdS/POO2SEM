
package funcionarios;

/**
 *
 * @author Marlon Santana dos Santos
 */
public class Gerente {
    public String nome;
    public String cpf;
    public double salario;
    
    public Gerente (String nome, String cpf){
        this.nome = nome;
        this.cpf = nome;
    }
}
