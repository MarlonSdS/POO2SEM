
package funcionarios;

/**
 *
 * @author Marlon Santana dos Santos
 */
public class Funcionario {
    public String nome;
    public String cpf;
    public double salario;
    
    public Funcionario(String nome, String cpf){
        this.nome = nome;
        this.cpf = cpf;
    }
}
