
package main;

import cliente.Cliente;
import funcionarios.Funcionario;
import funcionarios.Gerente;
import java.util.Scanner;
import loja.Loja;

/**
 *
 * @author Marlon Santana dos Santos
 */
public class Main {
    public static void main(String[] args) {
        Funcionario f1 = new Funcionario("João", "121212121-12");
        Gerente g1 = new Gerente("José", "232323223-23");
        Cliente c1 = new Cliente("Carlos", "565656565-56");
        Loja l1 = new Loja(135, "Rua da Paz");
        Scanner tc = new Scanner(System.in);
        
        System.out.println("Informe o salário do funcionário");
        f1.salario = tc.nextDouble();
        System.out.println("Informe o salário do gerente");
        g1.salario = tc.nextDouble();
        System.out.println("Informe o telefone do cliente");
        c1.telefone = tc.next();
        System.out.println("Informe o bairro da loja");
        l1.bairro = tc.next();
        
        System.out.println("Funcionário:");
        System.out.println(f1.nome);
        System.out.println(f1.cpf);
        System.out.println(f1.salario);
        
        System.out.println("Gerente:");
        System.out.println(g1.nome);
        System.out.println(g1.cpf);
        System.out.println(g1.salario);
        
        System.out.println("Cliente:");
        System.out.println(c1.nome);
        System.out.println(c1.cpf);
        System.out.println(c1.telefone);
        
        System.out.println("Loja");
        System.out.println(l1.num);
        System.out.println(l1.rua);
        System.out.println(l1.bairro);
        
    }
    
}
