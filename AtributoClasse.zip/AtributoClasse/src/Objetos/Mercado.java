
package objetos;

/**
 *
 * @author Marlon Santana dos S
 */
public class Mercado {
    public static String endereco;
    public static String cnpj;
    public static String nome;
    public static int numFuncionarios;
    public static int horaAbertura;
    
}
