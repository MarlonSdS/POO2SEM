
package objetos;

/**
 *
 * @author Marlon Santana dos S
 */
public class Endereco {
    public static int numero;
    public static String rua;
    public static String bairro;
    public static String cidade;
    public static String estado;
    
}
