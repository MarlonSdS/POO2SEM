
package Objetos;

/**
 *
 * @author Marlon Santana dos S
 */
public class Pessoa {
    public static String nome;
    public static String cpf;
    public static String nacionalidade;
    public static String telefone;
    public static int idade;
    
    public static void exibirInformacoes(){
        
        System.out.println(nome);
        System.out.println(cpf);
        System.out.println(nacionalidade);
        System.out.println(telefone);
        System.out.println(idade);
    }
}
