
package objetos;

/**
 *
 * @author Marlon Santana dos S
 */
public class Onibus {
    public static int numPassageiros;
    public static String saida;
    public static String destino;
    public static int horaSaida;
    public static int horaChegada;
    
}
