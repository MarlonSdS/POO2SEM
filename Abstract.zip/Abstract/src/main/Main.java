
package main;

import funcionario.Gerente;
import funcionario.Secretario;
import funcionario.ServicosGerais;
import funcionario.Funcionario;



public class Main {
    public static void calcularBonificacao(Funcionario f){
        f.bonificacao();
        if(f instanceof Gerente){
            System.out.println("Gerente: "+ (f.getSalario()+ f.getBonificacao()));
        }else if(f instanceof Secretario){
            System.out.println("Secretario: "+ (f.getSalario()+ f.getBonificacao()));
        }else{
            System.out.println("S. Gerais: "+ (f.getSalario()+ f.getBonificacao()));
        }
}
    
    public static void main(String[] args) {
        Gerente g = new Gerente();
        Secretario s = new Secretario();
        ServicosGerais sg = new ServicosGerais();
        
        g.setSalario(1000);
        s.setSalario(1000);
        sg.setSalario(1000);
       // calcularBonificacao(g);
       // calcularBonificacao(s);
        
        calcularBonificacao(sg);
        /*
        
        System.out.println("Gerente: "+ (g.getSalario()+ g.getBonificacao()));
        System.out.println("Secretario: "+ (s.getSalario()+ s.getBonificacao()));
        System.out.println("S. Gerais: "+ (sg.getSalario()+ sg.getBonificacao()));
       */ 
    }
}
