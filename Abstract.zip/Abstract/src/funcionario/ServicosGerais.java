
package funcionario;

public class ServicosGerais extends Funcionario{
    
    @Override
    public void bonificacao(){
        setBonificacao(getSalario() * 0.07);
    }
    
}
