
package funcionario;

public class Secretario extends Funcionario{
    
    @Override
    public void bonificacao(){
        setBonificacao(getSalario() * 0.05);
    }
    
}
